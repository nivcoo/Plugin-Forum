-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: mineweb
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum__configs`
--

DROP TABLE IF EXISTS `forum__configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__configs` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `config_name` varchar(30) DEFAULT NULL,
  `config_value` tinytext,
  `lang` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__configs`
--

LOCK TABLES `forum__configs` WRITE;
/*!40000 ALTER TABLE `forum__configs` DISABLE KEYS */;
INSERT INTO `forum__configs` VALUES (1,'useronline','1','Utilisateur en ligne'),(2,'statistics','1','Statistiques'),(3,'privatemsg','1','Message privés'),(4,'reportmsg','1','Signaler les messages'),(5,'notemsg','1','Noter les messages'),(6,'userpage','1','Profil utilisateur du forum'),(7,'forum','1','Forum'),(8,'socialnetwork','1','Réseaux sociaux');
/*!40000 ALTER TABLE `forum__configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__conversations`
--

DROP TABLE IF EXISTS `forum__conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__conversations` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(8) NOT NULL,
  `first` tinyint(1) DEFAULT '1',
  `read` tinyint(1) DEFAULT '1',
  `title` tinytext,
  `author_id` int(8) NOT NULL,
  `author_ip` varchar(15) NOT NULL,
  `msg_date` datetime NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__conversations`
--

LOCK TABLES `forum__conversations` WRITE;
/*!40000 ALTER TABLE `forum__conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__conversation_recipients`
--

DROP TABLE IF EXISTS `forum__conversation_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__conversation_recipients` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(8) NOT NULL,
  `author_recipient` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__conversation_recipients`
--

LOCK TABLES `forum__conversation_recipients` WRITE;
/*!40000 ALTER TABLE `forum__conversation_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__conversation_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__forums`
--

DROP TABLE IF EXISTS `forum__forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__forums` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_parent` int(8) NOT NULL,
  `id_user` int(8) NOT NULL,
  `position` int(3) NOT NULL,
  `forum_name` tinytext NOT NULL,
  `forum_description` tinytext,
  `forum_image` text,
  `lock` tinyint(1) DEFAULT '0',
  `permission` text,
  `automatic_lock` tinyint(1) DEFAULT '0',
  `visible` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__forums`
--

LOCK TABLES `forum__forums` WRITE;
/*!40000 ALTER TABLE `forum__forums` DISABLE KEYS */;
INSERT INTO `forum__forums` VALUES (1,0,1,1,'Mineweb','Ceci est une description','folder-open',0,NULL,0,NULL),(2,0,1,2,'Support','Ceci est une description','folder-open',0,NULL,0,NULL),(3,0,1,2,'Documentation','Ceci est une description','folder-open',0,NULL,0,NULL),(4,1,1,1,'Règlement','Ceci est une description','folder-open',0,NULL,0,NULL),(5,1,1,1,'Catégorie random','Ceci est une description','folder-open',0,NULL,0,NULL),(6,4,1,1,'Catégorie random','Ceci est une description','folder-open',0,NULL,0,NULL);
/*!40000 ALTER TABLE `forum__forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__forum_permissions`
--

DROP TABLE IF EXISTS `forum__forum_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__forum_permissions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(8) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT 'FORUM',
  `value` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__forum_permissions`
--

LOCK TABLES `forum__forum_permissions` WRITE;
/*!40000 ALTER TABLE `forum__forum_permissions` DISABLE KEYS */;
INSERT INTO `forum__forum_permissions` VALUES (1,1,'FORUM_MP_SEND','1'),(2,2,'FORUM_MP_SEND','1'),(3,3,'FORUM_MP_SEND','1'),(4,99,'FORUM_MP_SEND','1'),(5,1,'FORUM_MP_REPLY','1'),(6,2,'FORUM_MP_REPLY','1'),(7,3,'FORUM_MP_REPLY','1'),(8,99,'FORUM_MP_REPLY','1'),(9,1,'FORUM_TOPIC_SEND','1'),(10,2,'FORUM_TOPIC_SEND','1'),(11,3,'FORUM_TOPIC_SEND','1'),(12,99,'FORUM_TOPIC_SEND','1'),(13,1,'FORUM_TOPIC_REPLY','1'),(14,2,'FORUM_TOPIC_REPLY','1'),(15,3,'FORUM_TOPIC_REPLY','1'),(16,99,'FORUM_TOPIC_REPLY','1'),(17,1,'FORUM_TOPIC_STICK','1'),(18,2,'FORUM_TOPIC_STICK','1'),(19,3,'FORUM_TOPIC_STICK','1'),(20,99,'FORUM_TOPIC_STICK','0'),(21,1,'FORUM_TOPIC_LOCK','1'),(22,2,'FORUM_TOPIC_LOCK','1'),(23,3,'FORUM_TOPIC_LOCK','0'),(24,99,'FORUM_TOPIC_LOCK','0'),(25,1,'FORUM_MSGMY_EDIT','1'),(26,2,'FORUM_MSGMY_EDIT','1'),(27,3,'FORUM_MSGMY_EDIT','1'),(28,99,'FORUM_MSGMY_EDIT','1'),(29,1,'FORUM_MSG_EDIT','1'),(30,2,'FORUM_MSG_EDIT','1'),(31,3,'FORUM_MSG_EDIT','0'),(32,99,'FORUM_MSG_EDIT','0'),(33,1,'FORUM_MSGMY_DELETE','1'),(34,2,'FORUM_MSGMY_DELETE','1'),(35,3,'FORUM_MSGMY_DELETE','1'),(36,99,'FORUM_MSGMY_DELETE','1'),(37,1,'FORUM_MSG_DELETE','1'),(38,2,'FORUM_MSG_DELETE','1'),(39,3,'FORUM_MSG_DELETE','0'),(40,99,'FORUM_MSG_DELETE','0'),(41,1,'FORUM_MSG_REPORT','1'),(42,2,'FORUM_MSG_REPORT','1'),(43,3,'FORUM_MSG_REPORT','1'),(44,99,'FORUM_MSG_REPORT','1'),(45,1,'FORUM_TOPICMY_DELETE','1'),(46,2,'FORUM_TOPICMY_DELETE','1'),(47,3,'FORUM_TOPICMY_DELETE','1'),(48,99,'FORUM_TOPICMY_DELETE','0'),(49,1,'FORUM_TOPIC_DELETE','1'),(50,2,'FORUM_TOPIC_DELETE','1'),(51,3,'FORUM_TOPIC_DELETE','0'),(52,99,'FORUM_TOPIC_DELETE','0'),(53,1,'FORUM_VIEW_REPORT','1'),(54,2,'FORUM_VIEW_REPORT','1'),(55,3,'FORUM_VIEW_REPORT','0'),(56,99,'FORUM_VIEW_REPORT','0'),(57,1,'FORUM_MOOVE_TOPIC','1'),(58,2,'FORUM_MOOVE_TOPIC','1'),(59,3,'FORUM_MOOVE_TOPIC','1'),(60,99,'FORUM_MOOVE_TOPIC','0');
/*!40000 ALTER TABLE `forum__forum_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__groups`
--

DROP TABLE IF EXISTS `forum__groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__groups` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) DEFAULT NULL,
  `group_description` tinytext,
  `color` varchar(6) DEFAULT NULL,
  `position` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__groups`
--

LOCK TABLES `forum__groups` WRITE;
/*!40000 ALTER TABLE `forum__groups` DISABLE KEYS */;
INSERT INTO `forum__groups` VALUES (1,'Administrateur','Ceci est le groupe des administrateurs du serveur Minecraft','e74c3c',1),(2,'Modérateur','Ceci est le groupe des modérateurs du serveur Minecraft','e67e22',2),(3,'Développeur','Ceci est le groupe des développeurs du serveur Minecraft','2ecc71',3);
/*!40000 ALTER TABLE `forum__groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__groups_users`
--

DROP TABLE IF EXISTS `forum__groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__groups_users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_group` int(8) NOT NULL,
  `domin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__groups_users`
--

LOCK TABLES `forum__groups_users` WRITE;
/*!40000 ALTER TABLE `forum__groups_users` DISABLE KEYS */;
INSERT INTO `forum__groups_users` VALUES (1,1,1,1),(2,1,2,0),(3,1,3,0);
/*!40000 ALTER TABLE `forum__groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__histories`
--

DROP TABLE IF EXISTS `forum__histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__histories` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `id_user` int(8) NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '?',
  `category` tinytext NOT NULL,
  `action` tinytext NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__histories`
--

LOCK TABLES `forum__histories` WRITE;
/*!40000 ALTER TABLE `forum__histories` DISABLE KEYS */;
INSERT INTO `forum__histories` VALUES (1,'2017-06-20 03:53:43',1,'192.168.56.1','general','Configuration de base du site',''),(2,'2017-06-20 03:55:45',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : Test','<p>Test</p>'),(3,'2017-06-20 03:57:57',1,'192.168.56.1','lock_topic','PHPierre vient de verrouiller un topic','Test');
/*!40000 ALTER TABLE `forum__histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__insults`
--

DROP TABLE IF EXISTS `forum__insults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__insults` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `word` varchar(40) NOT NULL,
  `replace` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__insults`
--

LOCK TABLES `forum__insults` WRITE;
/*!40000 ALTER TABLE `forum__insults` DISABLE KEYS */;
INSERT INTO `forum__insults` VALUES (1,'merde','m****'),(2,'putin','p****'),(3,'fdp','');
/*!40000 ALTER TABLE `forum__insults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__msg_reports`
--

DROP TABLE IF EXISTS `forum__msg_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__msg_reports` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_msg` int(8) NOT NULL,
  `date` datetime NOT NULL,
  `reason` tinytext NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__msg_reports`
--

LOCK TABLES `forum__msg_reports` WRITE;
/*!40000 ALTER TABLE `forum__msg_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__msg_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__notes`
--

DROP TABLE IF EXISTS `forum__notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__notes` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_to_user` int(8) NOT NULL,
  `id_message` int(8) NOT NULL,
  `type` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__notes`
--

LOCK TABLES `forum__notes` WRITE;
/*!40000 ALTER TABLE `forum__notes` DISABLE KEYS */;
INSERT INTO `forum__notes` VALUES (1,1,1,1,1);
/*!40000 ALTER TABLE `forum__notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__profiles`
--

DROP TABLE IF EXISTS `forum__profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__profiles` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `description` varchar(167) DEFAULT NULL,
  `social` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__profiles`
--

LOCK TABLES `forum__profiles` WRITE;
/*!40000 ALTER TABLE `forum__profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__punishments`
--

DROP TABLE IF EXISTS `forum__punishments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__punishments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_to_user` int(8) NOT NULL,
  `date` datetime NOT NULL,
  `reason` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__punishments`
--

LOCK TABLES `forum__punishments` WRITE;
/*!40000 ALTER TABLE `forum__punishments` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__punishments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__topics`
--

DROP TABLE IF EXISTS `forum__topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__topics` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_parent` int(8) NOT NULL,
  `id_user` int(8) NOT NULL,
  `id_topic` int(8) NOT NULL,
  `name` tinytext,
  `first` tinyint(1) DEFAULT '0',
  `stick` tinyint(1) DEFAULT '0',
  `lock` tinyint(1) DEFAULT '0',
  `content` text NOT NULL,
  `date` datetime NOT NULL,
  `last_edit` datetime DEFAULT NULL,
  `permission` text,
  `visible` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__topics`
--

LOCK TABLES `forum__topics` WRITE;
/*!40000 ALTER TABLE `forum__topics` DISABLE KEYS */;
INSERT INTO `forum__topics` VALUES (1,4,1,1,'Votre premier Topic !',1,0,0,'Ceci est votre premier message. C\'est pour vous montrez un petit parçu du plugin.','2017-06-20 03:53:43','2017-06-20 03:53:43',NULL,NULL),(2,5,1,2,'Test',1,0,1,'<p>Test</p>','2017-06-20 03:55:45',NULL,NULL,NULL);
/*!40000 ALTER TABLE `forum__topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__viewws`
--

DROP TABLE IF EXISTS `forum__viewws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__viewws` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '?',
  `id_topic` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__viewws`
--

LOCK TABLES `forum__viewws` WRITE;
/*!40000 ALTER TABLE `forum__viewws` DISABLE KEYS */;
INSERT INTO `forum__viewws` VALUES (1,'2017-06-20 03:55:46','192.168.56.1',2);
/*!40000 ALTER TABLE `forum__viewws` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-20  4:24:36
