-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: mineweb
-- ------------------------------------------------------
-- Server version	5.7.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum__configs`
--

DROP TABLE IF EXISTS `forum__configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__configs` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `config_name` varchar(30) DEFAULT NULL,
  `config_value` tinytext,
  `lang` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__configs`
--

LOCK TABLES `forum__configs` WRITE;
/*!40000 ALTER TABLE `forum__configs` DISABLE KEYS */;
INSERT INTO `forum__configs` VALUES (1,'useronline','1','Utilisateur en ligne'),(2,'statistics','1','Statistiques'),(3,'privatemsg','1','Message privés'),(4,'reportmsg','1','Signaler les messages'),(5,'notemsg','1','Noter les messages'),(6,'userpage','1','Profil utilisateur du forum'),(7,'forum','1','Forum'),(8,'socialnetwork','1','Réseaux sociaux');
/*!40000 ALTER TABLE `forum__configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__conversations`
--

DROP TABLE IF EXISTS `forum__conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__conversations` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(8) NOT NULL,
  `first` tinyint(1) DEFAULT '1',
  `read` tinyint(1) DEFAULT '1',
  `title` tinytext,
  `author_id` int(8) NOT NULL,
  `author_ip` varchar(15) NOT NULL,
  `msg_date` datetime NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__conversations`
--

LOCK TABLES `forum__conversations` WRITE;
/*!40000 ALTER TABLE `forum__conversations` DISABLE KEYS */;
INSERT INTO `forum__conversations` VALUES (1,1,1,1,'no test',1,'192.168.56.1','2017-11-11 16:13:34','<p>no test</p>'),(2,2,1,1,'Salut à toi !',1,'192.168.56.1','2017-11-19 22:37:06','<p>Comment vas-tu ?</p>'),(3,2,0,1,'',2,'192.168.56.1','2017-12-03 21:37:54','<p>Bien et toi depuis tout ce temps ?</p>');
/*!40000 ALTER TABLE `forum__conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__conversation_recipients`
--

DROP TABLE IF EXISTS `forum__conversation_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__conversation_recipients` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(8) NOT NULL,
  `author_recipient` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__conversation_recipients`
--

LOCK TABLES `forum__conversation_recipients` WRITE;
/*!40000 ALTER TABLE `forum__conversation_recipients` DISABLE KEYS */;
INSERT INTO `forum__conversation_recipients` VALUES (1,1,2),(2,1,1),(3,2,2),(4,2,1);
/*!40000 ALTER TABLE `forum__conversation_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__forums`
--

DROP TABLE IF EXISTS `forum__forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__forums` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_parent` int(8) NOT NULL,
  `id_user` int(8) NOT NULL,
  `position` int(3) NOT NULL,
  `forum_name` tinytext NOT NULL,
  `forum_description` tinytext,
  `forum_image` text,
  `lock` tinyint(1) DEFAULT '0',
  `permission` text,
  `automatic_lock` tinyint(1) DEFAULT '0',
  `visible` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__forums`
--

LOCK TABLES `forum__forums` WRITE;
/*!40000 ALTER TABLE `forum__forums` DISABLE KEYS */;
INSERT INTO `forum__forums` VALUES (1,0,1,1,'Mineweb','Ceci est une description','folder-open',0,NULL,0,NULL),(2,0,1,2,'Support','Ceci est une description','folder-open',0,NULL,0,NULL),(3,0,1,2,'Documentation','Ceci est une description','folder-open',0,NULL,0,NULL),(4,1,1,1,'Règlement','Ceci est une description','folder-open',0,NULL,0,NULL),(5,1,1,1,'Catégorie random','Ceci est une description','folder-open',0,NULL,0,NULL),(6,4,1,1,'Catégorie random','Ceci est une description','folder-open',0,NULL,0,NULL),(7,1,1,3,'test',NULL,'times',0,NULL,0,'a:3:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";}'),(8,2,1,3,'test',NULL,'times',0,NULL,0,'a:3:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";}'),(9,2,1,4,'test',NULL,'times',0,NULL,0,'a:3:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";}'),(10,3,1,4,'test',NULL,'times',0,NULL,0,'a:3:{i:1;s:1:\"0\";i:2;s:1:\"0\";i:3;s:1:\"0\";}');
/*!40000 ALTER TABLE `forum__forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__forum_permissions`
--

DROP TABLE IF EXISTS `forum__forum_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__forum_permissions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(8) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT 'FORUM',
  `value` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__forum_permissions`
--

LOCK TABLES `forum__forum_permissions` WRITE;
/*!40000 ALTER TABLE `forum__forum_permissions` DISABLE KEYS */;
INSERT INTO `forum__forum_permissions` VALUES (1,1,'FORUM_MP_SEND','1'),(2,2,'FORUM_MP_SEND','1'),(3,3,'FORUM_MP_SEND','1'),(4,99,'FORUM_MP_SEND','1'),(5,1,'FORUM_MP_REPLY','1'),(6,2,'FORUM_MP_REPLY','1'),(7,3,'FORUM_MP_REPLY','1'),(8,99,'FORUM_MP_REPLY','1'),(9,1,'FORUM_TOPIC_SEND','1'),(10,2,'FORUM_TOPIC_SEND','1'),(11,3,'FORUM_TOPIC_SEND','1'),(12,99,'FORUM_TOPIC_SEND','1'),(13,1,'FORUM_TOPIC_REPLY','1'),(14,2,'FORUM_TOPIC_REPLY','1'),(15,3,'FORUM_TOPIC_REPLY','1'),(16,99,'FORUM_TOPIC_REPLY','1'),(17,1,'FORUM_TOPIC_STICK','1'),(18,2,'FORUM_TOPIC_STICK','1'),(19,3,'FORUM_TOPIC_STICK','1'),(20,99,'FORUM_TOPIC_STICK','0'),(21,1,'FORUM_TOPIC_LOCK','1'),(22,2,'FORUM_TOPIC_LOCK','1'),(23,3,'FORUM_TOPIC_LOCK','0'),(24,99,'FORUM_TOPIC_LOCK','0'),(25,1,'FORUM_MSGMY_EDIT','1'),(26,2,'FORUM_MSGMY_EDIT','1'),(27,3,'FORUM_MSGMY_EDIT','1'),(28,99,'FORUM_MSGMY_EDIT','1'),(29,1,'FORUM_MSG_EDIT','1'),(30,2,'FORUM_MSG_EDIT','1'),(31,3,'FORUM_MSG_EDIT','0'),(32,99,'FORUM_MSG_EDIT','0'),(33,1,'FORUM_MSGMY_DELETE','1'),(34,2,'FORUM_MSGMY_DELETE','1'),(35,3,'FORUM_MSGMY_DELETE','1'),(36,99,'FORUM_MSGMY_DELETE','1'),(37,1,'FORUM_MSG_DELETE','1'),(38,2,'FORUM_MSG_DELETE','1'),(39,3,'FORUM_MSG_DELETE','0'),(40,99,'FORUM_MSG_DELETE','0'),(41,1,'FORUM_MSG_REPORT','1'),(42,2,'FORUM_MSG_REPORT','1'),(43,3,'FORUM_MSG_REPORT','1'),(44,99,'FORUM_MSG_REPORT','1'),(45,1,'FORUM_TOPICMY_DELETE','1'),(46,2,'FORUM_TOPICMY_DELETE','1'),(47,3,'FORUM_TOPICMY_DELETE','1'),(48,99,'FORUM_TOPICMY_DELETE','0'),(49,1,'FORUM_TOPIC_DELETE','1'),(50,2,'FORUM_TOPIC_DELETE','1'),(51,3,'FORUM_TOPIC_DELETE','0'),(52,99,'FORUM_TOPIC_DELETE','0'),(53,1,'FORUM_VIEW_REPORT','1'),(54,2,'FORUM_VIEW_REPORT','1'),(55,3,'FORUM_VIEW_REPORT','0'),(56,99,'FORUM_VIEW_REPORT','0'),(57,1,'FORUM_MOOVE_TOPIC','1'),(58,2,'FORUM_MOOVE_TOPIC','1'),(59,3,'FORUM_MOOVE_TOPIC','1'),(60,99,'FORUM_MOOVE_TOPIC','0'),(61,4,'FORUM_MP_SEND','0'),(62,4,'FORUM_MP_REPLY','0'),(63,4,'FORUM_TOPIC_SEND','0'),(64,4,'FORUM_TOPIC_REPLY','0'),(65,4,'FORUM_TOPIC_STICK','0'),(66,4,'FORUM_TOPIC_LOCK','0'),(67,4,'FORUM_MSGMY_EDIT','0'),(68,4,'FORUM_MSG_EDIT','0'),(69,4,'FORUM_MSGMY_DELETE','0'),(70,4,'FORUM_MSG_DELETE','0'),(71,4,'FORUM_MSG_REPORT','0'),(72,4,'FORUM_TOPICMY_DELETE','0'),(73,4,'FORUM_TOPIC_DELETE','0'),(74,4,'FORUM_VIEW_REPORT','0'),(75,4,'FORUM_MOOVE_TOPIC','0');
/*!40000 ALTER TABLE `forum__forum_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__groups`
--

DROP TABLE IF EXISTS `forum__groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__groups` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) DEFAULT NULL,
  `group_description` tinytext,
  `color` varchar(6) DEFAULT NULL,
  `position` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__groups`
--

LOCK TABLES `forum__groups` WRITE;
/*!40000 ALTER TABLE `forum__groups` DISABLE KEYS */;
INSERT INTO `forum__groups` VALUES (1,'Administrateur','Ceci est le groupe des administrateurs du serveur Minecraft','e74c3c',1),(2,'Modérateur','Ceci est le groupe des modérateurs du serveur Minecraft','e67e22',2),(3,'Développeur','Ceci est le groupe des développeurs du serveur Minecraft','2ecc71',3),(4,'Test','Grade','20f3c8',4);
/*!40000 ALTER TABLE `forum__groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__groups_users`
--

DROP TABLE IF EXISTS `forum__groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__groups_users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_group` int(8) NOT NULL,
  `domin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__groups_users`
--

LOCK TABLES `forum__groups_users` WRITE;
/*!40000 ALTER TABLE `forum__groups_users` DISABLE KEYS */;
INSERT INTO `forum__groups_users` VALUES (1,1,1,1),(2,1,2,0),(3,1,3,0),(4,2,1,1),(5,2,2,0),(6,2,3,1),(7,1,4,1);
/*!40000 ALTER TABLE `forum__groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__histories`
--

DROP TABLE IF EXISTS `forum__histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__histories` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `id_user` int(8) NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '?',
  `category` tinytext NOT NULL,
  `action` tinytext NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__histories`
--

LOCK TABLES `forum__histories` WRITE;
/*!40000 ALTER TABLE `forum__histories` DISABLE KEYS */;
INSERT INTO `forum__histories` VALUES (1,'2017-12-02 16:58:40',1,'192.168.56.1','general','Configuration de base du site',''),(2,'2017-12-02 16:58:54',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : fsefsfsfsef','<p>fsefsfsfsef</p>'),(3,'2017-12-02 17:00:06',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : pipi','<p>pipi</p>'),(4,'2017-12-02 17:00:18',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : osef','<p>osef</p>'),(5,'2017-12-02 17:00:35',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : oui','<p>oui</p>'),(6,'2017-12-03 13:20:05',1,'192.168.56.1','edit_profile','PHPierre vient d\'editer son profil ',''),(7,'2017-12-03 17:30:32',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : &nbsp;Le dernier sujet du f','<p>&nbsp;Le dernier sujet du forum</p>'),(8,'2017-12-03 20:44:15',1,'192.168.56.1','delete_tag','PHPierre vient de supprimer un tag','1'),(9,'2017-12-03 20:57:26',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : test','<p>test</p>'),(10,'2017-12-03 20:57:38',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : test2','<p>test2</p>'),(11,'2017-12-03 21:10:25',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : un','<p>un</p>'),(12,'2017-12-03 21:10:37',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : deux','<p>deux</p>'),(13,'2017-12-03 21:10:50',1,'192.168.56.1','create_topic','PHPierre vient de créer un nouveau topic : trois','<p>trois</p>'),(14,'2017-12-04 19:18:11',1,'192.168.56.1','edit_profile','PHPierre vient d\'editer son profil ',''),(15,'2017-12-04 19:45:09',1,'192.168.56.1','stick_topic','PHPierre vient de mettre en avant un topic','oui'),(16,'2017-12-04 19:45:13',1,'192.168.56.1','unstick_topic','PHPierre vient de en plus mettre en avant un topic','oui'),(17,'2017-12-04 19:47:36',1,'192.168.56.1','add_message','PHPierre vient de modifier un message : oui','<p>oui</p>'),(18,'2017-12-04 19:49:18',1,'192.168.56.1','edit_permission','PHPierre a modifié les permission de  : Maysqli',''),(19,'2017-12-04 19:49:21',1,'192.168.56.1','edit_permission','PHPierre a modifié les permission de  : Maysqli',''),(20,'2017-12-04 19:50:22',1,'192.168.56.1','add_group','PHPierre vient d\'ajouter un groupe : Test',''),(21,'2017-12-04 19:50:38',1,'192.168.56.1','edit_permission','PHPierre a modifié les permission de  : PHPierre',''),(22,'2017-12-06 23:03:35',1,'192.168.56.1','add_thumb','',''),(23,'2017-12-06 23:03:38',1,'192.168.56.1','remove_thumb','',''),(24,'2017-12-06 23:12:19',1,'192.168.56.1','add_thumb','',''),(25,'2017-12-06 23:12:38',1,'192.168.56.1','remove_thumb','',''),(26,'2017-12-06 23:12:40',1,'192.168.56.1','add_thumb','','');
/*!40000 ALTER TABLE `forum__histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__insults`
--

DROP TABLE IF EXISTS `forum__insults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__insults` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `word` varchar(40) NOT NULL,
  `replace` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__insults`
--

LOCK TABLES `forum__insults` WRITE;
/*!40000 ALTER TABLE `forum__insults` DISABLE KEYS */;
INSERT INTO `forum__insults` VALUES (1,'merde','m****'),(2,'putin','p****'),(3,'fdp','');
/*!40000 ALTER TABLE `forum__insults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__msg_reports`
--

DROP TABLE IF EXISTS `forum__msg_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__msg_reports` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_msg` int(8) NOT NULL,
  `date` datetime NOT NULL,
  `reason` tinytext NOT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__msg_reports`
--

LOCK TABLES `forum__msg_reports` WRITE;
/*!40000 ALTER TABLE `forum__msg_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__msg_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__notes`
--

DROP TABLE IF EXISTS `forum__notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__notes` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_to_user` int(8) NOT NULL,
  `id_message` int(8) NOT NULL,
  `type` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__notes`
--

LOCK TABLES `forum__notes` WRITE;
/*!40000 ALTER TABLE `forum__notes` DISABLE KEYS */;
INSERT INTO `forum__notes` VALUES (1,1,1,1,1),(4,1,2,6,2);
/*!40000 ALTER TABLE `forum__notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__profiles`
--

DROP TABLE IF EXISTS `forum__profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__profiles` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `description` varchar(167) DEFAULT NULL,
  `social` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__profiles`
--

LOCK TABLES `forum__profiles` WRITE;
/*!40000 ALTER TABLE `forum__profiles` DISABLE KEYS */;
INSERT INTO `forum__profiles` VALUES (1,1,'','{\"facebook\":\"https:\\/\\/www.facebook.com\\/pierre.myx\",\"twitter\":\"\",\"youtube\":\"\",\"googleplus\":\"test\",\"snapchat\":\"test\"}'),(2,2,'',NULL);
/*!40000 ALTER TABLE `forum__profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__punishments`
--

DROP TABLE IF EXISTS `forum__punishments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__punishments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_user` int(8) NOT NULL,
  `id_to_user` int(8) NOT NULL,
  `date` datetime NOT NULL,
  `reason` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__punishments`
--

LOCK TABLES `forum__punishments` WRITE;
/*!40000 ALTER TABLE `forum__punishments` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum__punishments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__topics`
--

DROP TABLE IF EXISTS `forum__topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__topics` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_parent` int(8) DEFAULT NULL,
  `id_user` int(8) DEFAULT NULL,
  `id_topic` int(8) DEFAULT NULL,
  `name` tinytext,
  `first` tinyint(1) DEFAULT '0',
  `stick` tinyint(1) DEFAULT '0',
  `lock` tinyint(1) DEFAULT '0',
  `content` text,
  `date` datetime DEFAULT NULL,
  `last_edit` datetime DEFAULT NULL,
  `permission` text,
  `visible` tinytext,
  `tags` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__topics`
--

LOCK TABLES `forum__topics` WRITE;
/*!40000 ALTER TABLE `forum__topics` DISABLE KEYS */;
INSERT INTO `forum__topics` VALUES (1,4,1,1,'Votre premier Topic !',1,0,0,'Ceci est votre premier message. C\'est pour vous montrez un petit parçu du plugin.','2017-12-02 16:58:40','2017-12-02 16:58:40',NULL,NULL,NULL),(2,4,1,2,'esfefsef',1,0,0,'<p>fsefsfsfsef</p>','2017-12-02 16:58:54',NULL,NULL,NULL,NULL),(3,6,1,3,'pipi',1,0,0,'<p>pipi</p>','2017-12-02 17:00:06',NULL,NULL,NULL,NULL),(4,6,1,4,'osef',1,0,0,'<p>osef</p>','2017-12-02 17:00:18',NULL,NULL,NULL,NULL),(5,4,1,5,'oui',1,0,0,'<p>oui</p>','2017-12-02 17:00:34','2017-12-04 19:47:36',NULL,NULL,NULL),(6,4,2,6,'Le dernier sujet du forum',1,0,0,'<p>&nbsp;Le dernier sujet du forum</p>','2017-12-03 17:30:32',NULL,NULL,NULL,'2,'),(7,5,1,7,'test',1,0,0,'<p>test</p>','2017-12-03 20:57:26',NULL,NULL,NULL,NULL),(8,7,1,8,'test2',1,0,0,'<p>test2</p>','2017-12-03 20:57:38',NULL,NULL,NULL,NULL),(9,10,1,9,'un',1,0,0,'<p>un</p>','2017-12-03 21:10:25',NULL,NULL,NULL,NULL),(10,9,1,10,'deux',1,0,0,'<p>deux</p>','2017-12-03 21:10:37',NULL,NULL,NULL,NULL),(11,8,1,11,'trois',1,0,0,'<p>trois</p>','2017-12-03 21:10:50',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `forum__topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum__viewws`
--

DROP TABLE IF EXISTS `forum__viewws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum__viewws` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '?',
  `id_topic` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum__viewws`
--

LOCK TABLES `forum__viewws` WRITE;
/*!40000 ALTER TABLE `forum__viewws` DISABLE KEYS */;
INSERT INTO `forum__viewws` VALUES (1,'2017-11-11 01:11:41','192.168.56.1',2),(2,'2017-11-11 01:11:53','192.168.56.1',3),(3,'2017-11-11 01:12:07','192.168.56.1',4),(4,'2017-11-11 01:12:40','192.168.56.1',5),(5,'2017-11-18 13:49:40','192.168.56.1',2),(6,'2017-11-19 20:39:26','192.168.56.1',4),(7,'2017-11-19 22:54:28','192.168.56.1',1),(8,'2017-11-19 23:08:05','192.168.56.1',5),(9,'2017-11-19 23:08:05','192.168.56.1',5),(10,'2017-11-22 16:48:26','192.168.56.1',2),(11,'2017-12-01 20:35:36','192.168.56.1',1),(12,'2017-12-02 16:50:26','192.168.56.1',2),(13,'2017-12-02 16:55:40','192.168.56.1',3),(14,'2017-12-02 17:00:19','192.168.56.1',4),(15,'2017-12-02 17:00:35','192.168.56.1',5),(16,'2017-12-03 17:30:32','192.168.56.1',6),(17,'2017-12-03 20:57:26','192.168.56.1',7),(18,'2017-12-03 20:57:38','192.168.56.1',8),(19,'2017-12-03 21:10:26','192.168.56.1',9),(20,'2017-12-03 21:10:37','192.168.56.1',10),(21,'2017-12-03 21:10:50','192.168.56.1',11),(22,'2017-12-04 19:41:44','192.168.56.1',5),(23,'2017-12-06 23:03:18','192.168.56.1',6);
/*!40000 ALTER TABLE `forum__viewws` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-06 23:34:52
